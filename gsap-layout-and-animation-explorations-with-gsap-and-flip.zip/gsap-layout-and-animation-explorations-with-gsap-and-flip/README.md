# [gsap] ❍ Layout and Animation Explorations with GSAP and FLIP

A Pen created on CodePen.

Original URL: [https://codepen.io/Samiul-Karim/pen/yyeWWwN](https://codepen.io/Samiul-Karim/pen/yyeWWwN).

